# Angular4 authentication   
- this is the front-end layer of the app using anuglar 4 , 
- This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.5.0.

## Idea of the app 
 - simple user registration /  authentication 

## Development server

### installing the node module :
Use the following command in the project folder `npm install --build-from-source`  [NPM] https://www.npmjs.com/

### running the server
Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`.


## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).
