package Database;

import java.sql.Connection;
import java.sql.DriverManager;



public class Main {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		getConnection();
		try {

			String filePath = "E:\\DigitalCredentialXpress\\Data\\contact.csv";
			CSVLoader loader = new CSVLoader(getConnection());
			loader.loadCSV(filePath, "contact", true);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	public static Connection getConnection() throws Exception{
		Connection connection = null;
		try {
			String driver ="com.mysql.jdbc.Driver";
			String url = "jdbc:mysql://localhost:3306/digital6";
			String username = "root";
			String password = "Vivek@1986";
			
			String filePath = "E:\\DigitalCredentialXpress\\Data";
			
			Class.forName(driver);
			connection = DriverManager.getConnection(url, username, password);
			System.out.println("Connected");
			
			} catch (Exception e) {System.out.println(e);}
		
		return connection;
		

	}
	

}
